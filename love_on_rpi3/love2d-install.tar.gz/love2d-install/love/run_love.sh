#!/bin/sh
export SDL_VIDEO_GL_DRIVER=/opt/vc/lib/libbrcmGLESv2.so
export SDL_VIDEO_EGL_DRIVER=/opt/vc/lib/libbrcmEGL.so
stty -echo
LD_LIBRARY_PATH=/usr/local/games/love/lib:$LD_LIBRARY_PATH /usr/local/games/love/bin/love "$@"
stty echo

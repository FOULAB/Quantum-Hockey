#!/bin/sh
  if [ "$1" != "--no-update" ]; then
    sudo apt-get update
    sudo apt-get install libluajit-5.1-dev libphysfs-dev
  fi
  if [ -e /usr/local/games/love ]; then
    sudo rm -rf /usr/local/games/_love
    sudo mv /usr/local/games/love /usr/local/games/_love
  fi
  sudo mv love /usr/local/games
